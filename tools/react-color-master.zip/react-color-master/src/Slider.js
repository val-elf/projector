export default from './components/slider/Slider'
