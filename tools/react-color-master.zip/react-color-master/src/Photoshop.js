export default from './components/photoshop/Photoshop'
