export default from './components/common/ColorWrap'
