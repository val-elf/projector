export default from './components/swatches/Swatches'
