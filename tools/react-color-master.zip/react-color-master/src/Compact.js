export default from './components/compact/Compact'
