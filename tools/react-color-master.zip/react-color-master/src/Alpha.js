export default from './components/alpha/Alpha'
