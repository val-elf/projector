function d3_identity(d) {
  return d;
}
